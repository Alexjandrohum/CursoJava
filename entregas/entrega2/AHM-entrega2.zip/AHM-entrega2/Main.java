public class Main{
    public static void main(String srgs[]){
        FiguraGeometrica run = new FiguraGeometrica();
        run.init();
    }
}