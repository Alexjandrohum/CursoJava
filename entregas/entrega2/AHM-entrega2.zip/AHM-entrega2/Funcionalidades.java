public interface Funcionalidades{

    double getArea(int a, int b);

    String getRotar(int a);

    String dibujar(int a);
}