package util;

public class Constantes {

	public static final String tipoSexoHombre = "1";
	public static final String tipoSexoMujer = "2";

	public static final String HOMBRE = "hombre";
	public static final String MUJER = "mujer";
	
	public static final String rutaFile = "C:/Users/aleja/eclipse-workspace/entregas/entrega4/src/util/base.txt";

}
