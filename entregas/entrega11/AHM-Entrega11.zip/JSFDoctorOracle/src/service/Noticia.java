/**
 * Noticia.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package service;

public interface Noticia extends java.rmi.Remote {
    public service.NoticiaDomain getNoticia() throws java.rmi.RemoteException;
}
