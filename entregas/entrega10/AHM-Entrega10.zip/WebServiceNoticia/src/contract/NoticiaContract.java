package contract;

import domain.NoticiaDomain;

public interface NoticiaContract {
	
	NoticiaDomain getNoticia();

}
