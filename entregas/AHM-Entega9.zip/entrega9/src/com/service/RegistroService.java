package com.service;

import comconf.Doctor;

public interface RegistroService {

	void selectDoctor();

	boolean createdoctor(Doctor doctor);

}
