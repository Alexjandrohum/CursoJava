package com.service;

import com.domain.HorarioContent;

public interface HorarioService {
	int createHorario(HorarioContent horario, int idDoctor);
}
