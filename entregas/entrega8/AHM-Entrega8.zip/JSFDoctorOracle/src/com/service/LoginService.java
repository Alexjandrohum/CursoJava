package com.service;

import com.domain.Doctor;

public interface LoginService {

	Doctor login(String usuario, String contra);

}
