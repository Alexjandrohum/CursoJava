package com.service;

import com.domain.Doctor;

public interface RegistroService {
	
	boolean createDoctor(Doctor doctor);

}
