public class Comida{

	public String nombre;
	public double precio;
	public String detalle;	

	public Comida(String nombre, double precio){
		this.nombre = nombre;
		this.precio = precio;
	}

}