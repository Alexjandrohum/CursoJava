public class Persona{

	public String nombre;
	public int edad;

	Comida comida;

	public void comer(){
		System.out.println("Comió "+comida.nombre);
	}
	
}