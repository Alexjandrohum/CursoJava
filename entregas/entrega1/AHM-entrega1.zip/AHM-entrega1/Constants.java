public class Constants{
    public static final int nino = 2;
    public static final int adulto = 1;

    public static final int arroz = 1;
    public static final int pollo = 2;
    public static final int milaneza = 3;

    public static final int hamburgesa = 1;
    public static final int pizza = 2;
    public static final int papas = 3;

    public static final String pasatiempo = "pasatiempos";
    public static final String caricaturas = "caricaturas";

    public static final String hamburguesaName = "hamburguesa";
    public static final String pizzaName = "pizza";
    public static final String papasName = "papas";

    public static final String arrozName = "arroz";
    public static final String polloName = "pollo";
    public static final String milanesaName = "milanesa";

    public static final int arrozPrecio = 23;
    public static final int polloPrecio = 45;
    public static final int milanezaPrecio = 42;

    public static final int hamburgesaPrecio = 23;
    public static final int pizzaPrecio = 56;
    public static final int papasPrecio = 34;

    public static final String jugete = "Pelota";
    public static final String postre = "Fresas con crema";

}