package com.util;

public class Constantes {
	
	public static final String rutaArchivo = "/Volumes/ARCHIVOS/TrNetwork/entregas/entregas7/entrega7/src/com/util/bd.txt";

}
