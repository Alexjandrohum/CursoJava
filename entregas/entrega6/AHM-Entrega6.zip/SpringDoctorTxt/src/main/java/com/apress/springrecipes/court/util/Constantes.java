package com.apress.springrecipes.court.util;

public class Constantes {

	public static final String urlArchivo = "C:/Users/Alexjandrohum/Documents/curso/TrNetwork/entregas/entrega5/SpringDoctorTxt/src/main/java/com/apress/springrecipes/court/util/db.txt";

	public static final String mensaje = "Credenciales incorrectas";

	public static final int semanaOcupada = 2;

	public static final int diaNecesario = 3;
	public static final int saveHorario = 4;
	public static final int validacionDiasCorrecto = 5;
	public static final int errorSaveHorario = 6;
}
