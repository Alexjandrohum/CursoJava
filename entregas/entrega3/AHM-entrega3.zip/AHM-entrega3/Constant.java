public class Constant{
    public static String rutaArchivo = "archivo.txt";
}