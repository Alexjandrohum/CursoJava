public class Ingredientes{
    public String nombre;
    public int cantidad;
    public Ingredientes(String nombre, int cantidad){
        this.nombre = nombre;
        this.cantidad = cantidad;
    }
}