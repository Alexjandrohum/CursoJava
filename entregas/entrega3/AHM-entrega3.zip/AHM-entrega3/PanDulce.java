public class PanDulce{
    public int harina = 4;
    public int masa = 7;
    public int aceite = 3;
}