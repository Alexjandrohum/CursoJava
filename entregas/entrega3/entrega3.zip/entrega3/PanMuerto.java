public class PanMuerto{
    public int harina = 5;
    public int masa = 6;
    public int aceite = 1;
}