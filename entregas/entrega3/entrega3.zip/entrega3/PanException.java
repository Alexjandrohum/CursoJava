public class PanException extends Exception{
        PanException(String mensaje){
            super(mensaje);
    }
    
}