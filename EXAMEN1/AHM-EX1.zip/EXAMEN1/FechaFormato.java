public class FechaFormato{
    public String dia;
    public String mes;
    public int anio;

    public FechaFormato(String dia, String mes, int anio){
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }
}